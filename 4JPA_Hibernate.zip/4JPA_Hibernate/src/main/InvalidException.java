package main;

public class InvalidException extends Exception {
	public InvalidException(String msg) {
		System.out.println(msg);
	}
}